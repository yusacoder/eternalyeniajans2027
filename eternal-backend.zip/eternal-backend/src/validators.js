import { z } from 'zod';

// Kontrol karakterlerini temizler ve kırpar. (HTML encode ETMEZ: çıktı tarafında textContent/escape kullanılır.)
const clean = (s) => s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F\u200B-\u200F\u202A-\u202E]/g, '').trim();
const text = (min, max, label) =>
  z.string({ required_error: `${label} zorunlu.`, invalid_type_error: `${label} geçersiz.` })
    .transform(clean)
    .pipe(z.string().min(min, `${label} en az ${min} karakter olmalı.`).max(max, `${label} en fazla ${max} karakter olabilir.`));

const email = z.string({ required_error: 'E-posta zorunlu.' })
  .transform((s) => clean(s).toLowerCase())
  .pipe(z.string().email('Geçersiz e-posta adresi.').max(254));

const password = z.string({ required_error: 'Şifre zorunlu.' })
  .min(8, 'Şifre en az 8 karakter olmalı.')
  .max(72, 'Şifre en fazla 72 karakter olabilir.')
  .regex(/[A-Za-z]/, 'Şifre en az bir harf içermeli.')
  .regex(/[0-9]/, 'Şifre en az bir rakam içermeli.');

const otpCode = z.string().regex(/^\d{6}$/, 'Doğrulama kodu 6 haneli olmalı.');

export const registerSchema = z.object({
  name: text(2, 60, 'İsim'),
  surname: text(2, 60, 'Soyisim'),
  email,
  password,
});
export const loginSchema = z.object({ email, password: z.string().min(1, 'Şifre zorunlu.').max(72) });
export const verifyOtpSchema = z.object({ email, code: otpCode });
export const resendOtpSchema = z.object({ email });
export const profileSchema = z.object({ name: text(2, 60, 'İsim'), surname: text(2, 60, 'Soyisim') });

export const applicationSchema = z.object({
  fullname: text(3, 100, 'Ad Soyad'),
  nickname: text(2, 60, 'Takma Ad'),
  discord: text(2, 60, 'Instagram kullanıcı adı'),
  email,
  instagram: text(2, 60, 'Instagram'),
  followers: text(1, 30, 'Takipçi sayısı'),
  content_type: text(2, 60, 'İçerik türü'),
  avg_views: text(1, 30, 'Ortalama izlenme'),
  about: text(10, 2000, 'Kendinizi tanıtın'),
  why: text(10, 2000, 'Neden Eternal Production'),
  ad_consent: z.enum(['Evet, kabul ediyorum', 'Hayır, kabul etmiyorum'], { errorMap: () => ({ message: 'Reklam onayı seçilmeli.' }) }),
  agree_rules: z.literal('Kabul edildi', { errorMap: () => ({ message: 'Partner Programı Sözleşmesi onaylanmalı.' }) }),
  agree_content: z.literal('Kabul edildi', { errorMap: () => ({ message: 'İçerik ve Telif Politikası onaylanmalı.' }) }),
  agree_privacy: z.literal('Kabul edildi', { errorMap: () => ({ message: 'KVKK metni onaylanmalı.' }) }),
}).strip();

export const statusSchema = z.object({
  status: z.enum(['PENDING', 'REVIEWING', 'APPROVED', 'REJECTED'], { errorMap: () => ({ message: 'Geçersiz durum.' }) }),
  notify: z.boolean().optional().default(false),
});
export const messageSchema = z.object({
  body: text(2, 4000, 'Mesaj'),
  sendEmail: z.boolean().optional().default(true),
});

const domain = z.string({ required_error: 'Domain zorunlu.' })
  .transform((s) => clean(s).toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split(/[/?#]/)[0])
  .pipe(z.string().max(253).regex(/^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,}$/, 'Geçerli bir domain girin (örn. ornek.com).'));
export const siteSchema = z.object({ domain, label: z.preprocess((v) => (v === '' ? undefined : v), text(1, 80, 'Etiket').optional()) });

export const avatarSchema = z.object({
  avatarUrl: z.preprocess(
    (v) => (typeof v === 'string' && v.trim() === '' ? null : v),
    z.string().trim().max(500).url('Geçerli bir URL girin.')
      .refine((u) => u.startsWith('https://'), 'Yalnızca https:// bağlantıları kabul edilir.')
      .nullable(),
  ),
});
