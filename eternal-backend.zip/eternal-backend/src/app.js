import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cookieParser from 'cookie-parser';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { allowedOrigins, isProd } from './config/env.js';
import { errorHandler, notFound } from './middlewares/errorHandler.js';
import { originGuard } from './middlewares/originGuard.js';
import { apiLimiter } from './middlewares/rateLimiter.js';
import routes from './routes/index.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const app = express();

app.disable('x-powered-by');
if (isProd) app.set('trust proxy', 1); // Render/Railway/Fly gibi reverse proxy arkasında doğru IP için

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        'font-src': ["'self'", 'https://fonts.gstatic.com'],
        'img-src': ["'self'", 'data:', 'https:'],
        'connect-src': ["'self'"],
        'form-action': ["'self'"],
        'frame-ancestors': ["'none'"],
        'object-src': ["'none'"],
        'upgrade-insecure-requests': isProd ? [] : null,
      },
    },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }),
);

app.use(cors({ origin: allowedOrigins, credentials: true }));
app.use(express.json({ limit: '50kb' }));
app.use(cookieParser());

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/v1', apiLimiter, originGuard, routes);
app.use('/api', notFound);

// Mevcut statik site (Vercel'deki cleanUrls davranışı: /basvuru → basvuru.html)
app.use(express.static(path.join(root, 'public'), { extensions: ['html'], maxAge: isProd ? '1h' : 0 }));
app.use((_req, res) => res.status(404).sendFile(path.join(root, 'public', 'index.html')));

app.use(errorHandler);
export default app;
