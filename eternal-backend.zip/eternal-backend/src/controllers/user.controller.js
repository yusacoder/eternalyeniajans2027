import { prisma } from '../config/db.js';
import { asyncHandler } from '../utils/errors.js';
import { publicUser } from '../utils/security.js';

export const updateProfile = asyncHandler(async (req, res) => {
  const { name, surname } = req.body; // yalnızca isim/soyisim düzenlenebilir
  const user = await prisma.user.update({ where: { id: req.user.id }, data: { name, surname } });
  res.json({ user: publicUser(user) });
});

export const myApplications = asyncHandler(async (req, res) => {
  const applications = await prisma.application.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
    select: {
      id: true, nickname: true, instagram: true, status: true, createdAt: true, updatedAt: true,
      messages: { orderBy: { createdAt: 'asc' }, select: { id: true, body: true, createdAt: true } },
    },
  });
  res.json({ applications });
});

export const mySites = asyncHandler(async (req, res) => {
  const sites = await prisma.site.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
    select: { id: true, domain: true, label: true, createdAt: true },
  });
  res.json({ sites });
});
