import { prisma } from '../config/db.js';
import { env } from '../config/env.js';
import { sendMail } from '../config/mail.js';
import { asyncHandler } from '../utils/errors.js';

export const createApplication = asyncHandler(async (req, res) => {
  const b = req.body;
  const application = await prisma.application.create({
    data: {
      userId: req.user?.id ?? null, // oturum açıksa hesaba bağlanır, değilse anonim başvuru
      fullname: b.fullname,
      nickname: b.nickname,
      instagramHandle: b.discord,
      email: b.email,
      instagram: b.instagram,
      followers: b.followers,
      contentType: b.content_type,
      avgViews: b.avg_views,
      about: b.about,
      why: b.why,
      adConsent: b.ad_consent,
    },
    select: { id: true },
  });

  const notify = env.ADMIN_NOTIFY_EMAIL || env.ADMIN_EMAIL;
  if (notify) {
    sendMail({
      to: notify,
      subject: `Yeni Partner Başvurusu — ${b.nickname}`,
      text: `Yeni başvuru alındı.\n\nAd Soyad: ${b.fullname}\nTakma Ad: ${b.nickname}\nE-posta: ${b.email}\nInstagram: ${b.instagram}\nTakipçi: ${b.followers}\n\nAdmin panelinden inceleyin: ${env.APP_URL}/admin`,
    }).catch(() => {});
  }
  res.status(201).json({ ok: true, id: application.id });
});
