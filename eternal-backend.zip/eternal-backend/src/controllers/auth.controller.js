import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { prisma } from '../config/db.js';
import { env, isProd } from '../config/env.js';
import { sendMail } from '../config/mail.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { clearSession, generateOtp, hashOtp, issueSession, publicUser, safeEqual } from '../utils/security.js';

const OTP_TTL_MS = 10 * 60 * 1000;
const OTP_RESEND_COOLDOWN_MS = 60 * 1000;
const OTP_MAX_ATTEMPTS = 5;
// Kullanıcı yokken de bcrypt çalıştırıp zamanlama farkını gizlemek için
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 12);

async function sendOtp(user) {
  const existing = await prisma.otpCode.findUnique({ where: { userId: user.id } });
  if (existing && Date.now() - existing.lastSentAt.getTime() < OTP_RESEND_COOLDOWN_MS) {
    throw new AppError(429, 'Yeni kod istemeden önce lütfen 1 dakika bekleyin.', 'OTP_COOLDOWN');
  }
  const code = generateOtp();
  const data = { codeHash: hashOtp(code), expiresAt: new Date(Date.now() + OTP_TTL_MS), attempts: 0, lastSentAt: new Date() };
  await prisma.otpCode.upsert({ where: { userId: user.id }, update: data, create: { userId: user.id, ...data } });
  await sendMail({
    to: user.email,
    subject: 'Eternal Production — E-posta doğrulama kodunuz',
    text: `Merhaba ${user.name},\n\nDoğrulama kodunuz: ${code}\n\nKod 10 dakika geçerlidir. Bu işlemi siz yapmadıysanız bu e-postayı yok sayabilirsiniz.`,
  });
}

export const register = asyncHandler(async (req, res) => {
  const { name, surname, email, password } = req.body;
  const existing = await prisma.user.findUnique({ where: { email } });

  if (existing?.emailVerified) {
    throw new AppError(409, existing.passwordHash
      ? 'Bu e-posta ile kayıtlı bir hesap zaten var. Giriş yapabilirsiniz.'
      : 'Bu e-posta Google ile kayıtlı. Lütfen "Google ile giriş yap" seçeneğini kullanın.', 'EMAIL_TAKEN');
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = existing
    ? await prisma.user.update({ where: { id: existing.id }, data: { name, surname, passwordHash } })
    : await prisma.user.create({ data: { name, surname, email, passwordHash } });

  await sendOtp(user);
  res.status(201).json({ ok: true, needsVerification: true, email });
});

export const verifyOtp = asyncHandler(async (req, res) => {
  const { email, code } = req.body;
  const fail = () => new AppError(400, 'Kod hatalı veya süresi dolmuş.', 'OTP_INVALID');

  const user = await prisma.user.findUnique({ where: { email }, include: { otp: true } });
  if (!user || !user.otp) throw fail();
  if (user.otp.attempts >= OTP_MAX_ATTEMPTS) throw new AppError(429, 'Çok fazla hatalı deneme. Yeni kod isteyin.', 'OTP_LOCKED');
  if (user.otp.expiresAt < new Date()) throw fail();

  if (!safeEqual(hashOtp(code), user.otp.codeHash)) {
    await prisma.otpCode.update({ where: { userId: user.id }, data: { attempts: { increment: 1 } } });
    throw fail();
  }

  const [verified] = await prisma.$transaction([
    prisma.user.update({ where: { id: user.id }, data: { emailVerified: true } }),
    prisma.otpCode.delete({ where: { userId: user.id } }),
  ]);
  issueSession(res, verified);
  res.json({ user: publicUser(verified) });
});

export const resendOtp = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { email: req.body.email } });
  // Hesap var mı yok mu belli etmemek için her durumda aynı cevap
  if (user && !user.emailVerified && user.passwordHash) await sendOtp(user);
  res.json({ ok: true });
});

export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await prisma.user.findUnique({ where: { email } });
  const valid = await bcrypt.compare(password, user?.passwordHash || DUMMY_HASH);
  if (!user || !user.passwordHash || !valid) throw new AppError(401, 'E-posta veya şifre hatalı.', 'BAD_CREDENTIALS');

  if (!user.emailVerified) {
    await sendOtp(user).catch(() => {});
    throw new AppError(403, 'E-posta adresiniz doğrulanmamış. Yeni bir doğrulama kodu gönderdik.', 'EMAIL_NOT_VERIFIED');
  }
  issueSession(res, user);
  res.json({ user: publicUser(user) });
});

export const logout = (_req, res) => {
  clearSession(res);
  res.json({ ok: true });
};

export const me = (req, res) => {
  res.json({ user: req.user ? publicUser(req.user) : null });
};

/* ---------------- Google OAuth 2.0 (Authorization Code + state) ---------------- */
const STATE_COOKIE = 'ep_oauth_state';
const redirectUri = () => `${env.APP_URL.replace(/\/$/, '')}/api/v1/auth/google/callback`;

export const googleStart = (_req, res) => {
  if (!env.GOOGLE_CLIENT_ID || !env.GOOGLE_CLIENT_SECRET) {
    return res.status(503).json({ error: 'Google ile giriş yapılandırılmamış.', code: 'GOOGLE_DISABLED' });
  }
  const state = crypto.randomBytes(24).toString('hex');
  res.cookie(STATE_COOKIE, state, {
    httpOnly: true, secure: isProd, sameSite: 'lax', maxAge: 10 * 60 * 1000, path: '/api/v1/auth/google',
  });
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID,
    redirect_uri: redirectUri(),
    response_type: 'code',
    scope: 'openid email profile',
    state,
    prompt: 'select_account',
  });
  res.redirect(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
};

export const googleCallback = asyncHandler(async (req, res) => {
  const fail = () => res.redirect('/giris?error=google');
  const { code, state } = req.query;
  const cookieState = req.cookies?.[STATE_COOKIE];
  res.clearCookie(STATE_COOKIE, { path: '/api/v1/auth/google' });
  if (typeof code !== 'string' || typeof state !== 'string' || !cookieState || !safeEqual(state, cookieState)) return fail();

  try {
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: env.GOOGLE_CLIENT_ID,
        client_secret: env.GOOGLE_CLIENT_SECRET,
        redirect_uri: redirectUri(),
        grant_type: 'authorization_code',
      }),
    });
    if (!tokenRes.ok) return fail();
    const { access_token: accessToken } = await tokenRes.json();

    const infoRes = await fetch('https://openidconnect.googleapis.com/v1/userinfo', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    if (!infoRes.ok) return fail();
    const info = await infoRes.json();
    if (!info.sub || !info.email || info.email_verified !== true) return fail();

    const email = String(info.email).toLowerCase();
    const name = String(info.given_name || info.name || 'Kullanıcı').slice(0, 60);
    const surname = String(info.family_name || '').slice(0, 60);

    let user = await prisma.user.findUnique({ where: { googleId: info.sub } });
    if (!user) {
      const byEmail = await prisma.user.findUnique({ where: { email } });
      if (byEmail) {
        // Doğrulanmamış şifreli bir ön-kayıt varsa şifreyi sil (hesap ele geçirme / pre-registration saldırısına karşı)
        user = await prisma.user.update({
          where: { id: byEmail.id },
          data: { googleId: info.sub, emailVerified: true, ...(byEmail.emailVerified ? {} : { passwordHash: null }) },
        });
      } else {
        user = await prisma.user.create({ data: { email, name, surname, googleId: info.sub, emailVerified: true } });
      }
    }
    issueSession(res, user);
    res.redirect('/hesabim');
  } catch (err) {
    console.error('Google OAuth hatası:', err.message);
    fail();
  }
});
