import { prisma } from '../config/db.js';
import { env } from '../config/env.js';
import { sendMail } from '../config/mail.js';
import { AppError, asyncHandler } from '../utils/errors.js';
import { publicUser } from '../utils/security.js';

const PAGE_SIZE = 25;
const STATUS_TR = { PENDING: 'Beklemede', REVIEWING: 'İncelemede', APPROVED: 'Onaylandı', REJECTED: 'Reddedildi' };
const STATUSES = Object.keys(STATUS_TR);
const page = (q) => Math.max(1, parseInt(q.page, 10) || 1);

export const stats = asyncHandler(async (_req, res) => {
  const [users, byStatus] = await Promise.all([
    prisma.user.count(),
    prisma.application.groupBy({ by: ['status'], _count: { _all: true } }),
  ]);
  const applications = Object.fromEntries(STATUSES.map((s) => [s, 0]));
  for (const row of byStatus) applications[row.status] = row._count._all;
  res.json({ users, applications });
});

export const listApplications = asyncHandler(async (req, res) => {
  const where = {};
  if (STATUSES.includes(req.query.status)) where.status = req.query.status;
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  if (q) {
    where.OR = ['fullname', 'nickname', 'email', 'instagram'].map((f) => ({ [f]: { contains: q, mode: 'insensitive' } }));
  }
  const p = page(req.query);
  const [total, items] = await Promise.all([
    prisma.application.count({ where }),
    prisma.application.findMany({
      where, orderBy: { createdAt: 'desc' }, skip: (p - 1) * PAGE_SIZE, take: PAGE_SIZE,
      select: { id: true, fullname: true, nickname: true, email: true, instagram: true, followers: true, status: true, createdAt: true, userId: true },
    }),
  ]);
  res.json({ items, total, page: p, pageSize: PAGE_SIZE });
});

export const getApplication = asyncHandler(async (req, res) => {
  const application = await prisma.application.findUnique({
    where: { id: req.params.id },
    include: { messages: { orderBy: { createdAt: 'asc' } }, user: { select: { id: true, email: true, name: true, surname: true } } },
  });
  if (!application) throw new AppError(404, 'Başvuru bulunamadı.', 'NOT_FOUND');
  res.json({ application });
});

export const setApplicationStatus = asyncHandler(async (req, res) => {
  const { status, notify } = req.body;
  const exists = await prisma.application.findUnique({ where: { id: req.params.id } });
  if (!exists) throw new AppError(404, 'Başvuru bulunamadı.', 'NOT_FOUND');
  const application = await prisma.application.update({ where: { id: exists.id }, data: { status } });
  if (notify && exists.status !== status) {
    sendMail({
      to: application.email,
      subject: 'Eternal Production — Başvuru durumunuz güncellendi',
      text: `Merhaba ${application.fullname},\n\nPartner başvurunuzun durumu güncellendi: ${STATUS_TR[status]}.\n\nEternal Production`,
    }).catch(() => {});
  }
  res.json({ application: { id: application.id, status: application.status } });
});

export const sendApplicationMessage = asyncHandler(async (req, res) => {
  const { body, sendEmail } = req.body;
  const application = await prisma.application.findUnique({ where: { id: req.params.id } });
  if (!application) throw new AppError(404, 'Başvuru bulunamadı.', 'NOT_FOUND');

  let emailed = false;
  if (sendEmail) {
    emailed = await sendMail({
      to: application.email,
      subject: 'Eternal Production — Başvurunuz hakkında yanıt',
      text: `Merhaba ${application.fullname},\n\n${body}\n\n— Eternal Production Ekibi\n${env.APP_URL}`,
    });
  }
  const message = await prisma.applicationMessage.create({ data: { applicationId: application.id, body, emailed } });
  res.status(201).json({ message });
});

export const listUsers = asyncHandler(async (req, res) => {
  const where = {};
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  if (q) where.OR = ['email', 'name', 'surname'].map((f) => ({ [f]: { contains: q, mode: 'insensitive' } }));
  const p = page(req.query);
  const [total, users] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({
      where, orderBy: { createdAt: 'desc' }, skip: (p - 1) * PAGE_SIZE, take: PAGE_SIZE,
      include: { _count: { select: { sites: true, applications: true } } },
    }),
  ]);
  res.json({
    total, page: p, pageSize: PAGE_SIZE,
    items: users.map((u) => ({ ...publicUser(u), sites: u._count.sites, applications: u._count.applications })),
  });
});

export const getUser = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    include: { sites: { orderBy: { createdAt: 'desc' } }, applications: { orderBy: { createdAt: 'desc' }, select: { id: true, nickname: true, status: true, createdAt: true } } },
  });
  if (!user) throw new AppError(404, 'Kullanıcı bulunamadı.', 'NOT_FOUND');
  res.json({ user: { ...publicUser(user), sites: user.sites, applications: user.applications } });
});

export const addSite = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!user) throw new AppError(404, 'Kullanıcı bulunamadı.', 'NOT_FOUND');
  try {
    const site = await prisma.site.create({ data: { userId: user.id, domain: req.body.domain, label: req.body.label ?? null } });
    res.status(201).json({ site });
  } catch (e) {
    if (e.code === 'P2002') throw new AppError(409, 'Bu site bu kullanıcıya zaten atanmış.', 'DUPLICATE');
    throw e;
  }
});

export const deleteSite = asyncHandler(async (req, res) => {
  try {
    await prisma.site.delete({ where: { id: req.params.id } });
  } catch (e) {
    if (e.code === 'P2025') throw new AppError(404, 'Site bulunamadı.', 'NOT_FOUND');
    throw e;
  }
  res.json({ ok: true });
});

export const setAvatar = asyncHandler(async (req, res) => {
  // Güvenlik notu: URL sunucuda İNDİRİLMEZ (SSRF riski). Sadece https URL doğrulanıp saklanır, tarayıcı yükler.
  const user = await prisma.user.update({ where: { id: req.user.id }, data: { avatarUrl: req.body.avatarUrl } });
  res.json({ user: publicUser(user) });
});
