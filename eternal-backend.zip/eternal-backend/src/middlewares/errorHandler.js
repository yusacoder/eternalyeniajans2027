import { ZodError } from 'zod';
import { isProd } from '../config/env.js';

export function notFound(_req, res) {
  res.status(404).json({ error: 'Bulunamadı.', code: 'NOT_FOUND' });
}

export function errorHandler(err, _req, res, _next) {
  if (err instanceof ZodError) {
    return res.status(400).json({
      error: err.issues[0]?.message || 'Gönderilen bilgiler geçersiz.',
      code: 'VALIDATION',
      fields: err.issues.map((i) => ({ field: i.path.join('.'), message: i.message })),
    });
  }
  if (err?.type === 'entity.parse.failed') return res.status(400).json({ error: 'Geçersiz JSON.', code: 'BAD_JSON' });
  if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'İstek çok büyük.', code: 'TOO_LARGE' });
  if (err?.status && err.status < 500) return res.status(err.status).json({ error: err.message, code: err.code });
  console.error(err);
  res.status(500).json({ error: 'Sunucu hatası.', code: 'INTERNAL', ...(isProd ? {} : { detail: String(err?.message) }) });
}
