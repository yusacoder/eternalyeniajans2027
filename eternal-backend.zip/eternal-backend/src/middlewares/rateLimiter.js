import rateLimit from 'express-rate-limit';

const make = (windowMin, max, message) =>
  rateLimit({
    windowMs: windowMin * 60 * 1000,
    limit: max,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    message: { error: message, code: 'RATE_LIMITED' },
  });

export const apiLimiter = make(15, 300, 'Çok fazla istek gönderdiniz. Lütfen biraz bekleyin.');
export const authLimiter = make(15, 10, 'Çok fazla giriş/kayıt denemesi. 15 dakika sonra tekrar deneyin.');
export const otpLimiter = make(15, 8, 'Çok fazla doğrulama denemesi. 15 dakika sonra tekrar deneyin.');
export const applicationLimiter = make(60, 5, 'Saatlik başvuru limitine ulaştınız. Lütfen daha sonra tekrar deneyin.');
