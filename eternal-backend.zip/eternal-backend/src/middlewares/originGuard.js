import { allowedOrigins } from '../config/env.js';
import { AppError } from '../utils/errors.js';

/**
 * CSRF savunmasının 2. katmanı (1. katman: SameSite=Strict çerez).
 * Durum değiştiren isteklerde Origin (yoksa Referer) izinli listede olmalı.
 */
export function originGuard(req, _res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  let source = req.get('origin');
  if (!source && req.get('referer')) {
    try { source = new URL(req.get('referer')).origin; } catch { source = null; }
  }
  if (!source || !allowedOrigins.includes(source)) {
    return next(new AppError(403, 'İstek kaynağı doğrulanamadı.', 'BAD_ORIGIN'));
  }
  next();
}
