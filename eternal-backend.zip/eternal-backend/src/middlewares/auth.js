import { prisma } from '../config/db.js';
import { AppError } from '../utils/errors.js';
import { SESSION_COOKIE, verifyToken } from '../utils/security.js';

async function loadUser(req) {
  const token = req.cookies?.[SESSION_COOKIE];
  if (!token) return null;
  try {
    const payload = verifyToken(token);
    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    return user && user.emailVerified ? user : null;
  } catch {
    return null;
  }
}

export async function optionalAuth(req, _res, next) {
  try {
    req.user = await loadUser(req);
    next();
  } catch (e) {
    next(e);
  }
}
export async function requireAuth(req, _res, next) {
  try {
    req.user = await loadUser(req);
    if (!req.user) throw new AppError(401, 'Oturum açmanız gerekiyor.', 'UNAUTHENTICATED');
    next();
  } catch (e) {
    next(e);
  }
}
export function requireAdmin(req, _res, next) {
  if (!req.user || req.user.role !== 'ADMIN') return next(new AppError(403, 'Bu işlem için yetkiniz yok.', 'FORBIDDEN'));
  next();
}
