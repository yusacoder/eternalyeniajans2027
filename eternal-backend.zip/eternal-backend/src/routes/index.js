import { Router } from 'express';
import * as auth from '../controllers/auth.controller.js';
import * as user from '../controllers/user.controller.js';
import * as app from '../controllers/application.controller.js';
import * as admin from '../controllers/admin.controller.js';
import { optionalAuth, requireAdmin, requireAuth } from '../middlewares/auth.js';
import { applicationLimiter, authLimiter, otpLimiter } from '../middlewares/rateLimiter.js';
import { validate } from '../middlewares/validate.js';
import * as v from '../validators.js';

const router = Router();

// ---- Auth ----
router.post('/auth/register', authLimiter, validate(v.registerSchema), auth.register);
router.post('/auth/verify-otp', otpLimiter, validate(v.verifyOtpSchema), auth.verifyOtp);
router.post('/auth/resend-otp', otpLimiter, validate(v.resendOtpSchema), auth.resendOtp);
router.post('/auth/login', authLimiter, validate(v.loginSchema), auth.login);
router.post('/auth/logout', auth.logout);
router.get('/auth/me', optionalAuth, auth.me);
router.get('/auth/google', authLimiter, auth.googleStart);
router.get('/auth/google/callback', authLimiter, auth.googleCallback);

// ---- Başvuru (oturum opsiyonel) ----
router.post('/applications', applicationLimiter, optionalAuth, validate(v.applicationSchema), app.createApplication);

// ---- Kullanıcı paneli ----
router.patch('/user/profile', requireAuth, validate(v.profileSchema), user.updateProfile);
router.get('/user/applications', requireAuth, user.myApplications);
router.get('/user/sites', requireAuth, user.mySites);

// ---- Admin ----
const adm = Router();
adm.use(requireAuth, requireAdmin);
adm.get('/stats', admin.stats);
adm.get('/applications', admin.listApplications);
adm.get('/applications/:id', admin.getApplication);
adm.patch('/applications/:id/status', validate(v.statusSchema), admin.setApplicationStatus);
adm.post('/applications/:id/messages', validate(v.messageSchema), admin.sendApplicationMessage);
adm.get('/users', admin.listUsers);
adm.get('/users/:id', admin.getUser);
adm.post('/users/:id/sites', validate(v.siteSchema), admin.addSite);
adm.delete('/sites/:id', admin.deleteSite);
adm.patch('/profile/avatar', validate(v.avatarSchema), admin.setAvatar);
router.use('/admin', adm);

export default router;
