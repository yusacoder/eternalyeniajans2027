import 'dotenv/config';
import { z } from 'zod';

const emptyToUndef = (v) => (typeof v === 'string' && v.trim() === '' ? undefined : v);
const opt = (schema) => z.preprocess(emptyToUndef, schema.optional());

const schema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().default(3000),
  APP_URL: z.string().url().default('http://localhost:3000'),
  ALLOWED_ORIGINS: z.string().default(''),
  DATABASE_URL: z.string().min(1, 'DATABASE_URL zorunlu'),
  JWT_SECRET: z.string().min(32, 'JWT_SECRET en az 32 karakter olmalı'),
  OTP_SECRET: z.string().min(16, 'OTP_SECRET en az 16 karakter olmalı'),
  JWT_EXPIRES_DAYS: z.coerce.number().int().min(1).max(60).default(7),
  GOOGLE_CLIENT_ID: opt(z.string()),
  GOOGLE_CLIENT_SECRET: opt(z.string()),
  SMTP_HOST: opt(z.string()),
  SMTP_PORT: z.coerce.number().default(587),
  SMTP_SECURE: z.enum(['true', 'false']).default('false'),
  SMTP_USER: opt(z.string()),
  SMTP_PASS: opt(z.string()),
  MAIL_FROM: z.string().default('Eternal Production <no-reply@localhost>'),
  ADMIN_NOTIFY_EMAIL: opt(z.string().email()),
  ADMIN_EMAIL: opt(z.string().email()),
});

const parsed = schema.safeParse(process.env);
if (!parsed.success) {
  console.error('Ortam değişkenleri hatalı (.env dosyanı kontrol et):');
  for (const issue of parsed.error.issues) console.error(` - ${issue.path.join('.')}: ${issue.message}`);
  process.exit(1);
}

export const env = parsed.data;
export const isProd = env.NODE_ENV === 'production';
export const appOrigin = new URL(env.APP_URL).origin;
export const allowedOrigins = [
  appOrigin,
  ...env.ALLOWED_ORIGINS.split(',').map((s) => s.trim()).filter(Boolean),
];
