import nodemailer from 'nodemailer';
import { env } from './env.js';

const transporter = env.SMTP_HOST
  ? nodemailer.createTransport({
      host: env.SMTP_HOST,
      port: env.SMTP_PORT,
      secure: env.SMTP_SECURE === 'true',
      auth: env.SMTP_USER ? { user: env.SMTP_USER, pass: env.SMTP_PASS } : undefined,
    })
  : null;

export function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

/** E-posta gönderir. SMTP tanımlı değilse içeriği konsola yazar (yalnızca geliştirme). */
export async function sendMail({ to, subject, text }) {
  const html = `<div style="font-family:Arial,sans-serif;line-height:1.6;color:#14151f;white-space:pre-wrap">${escapeHtml(text)}</div>`;
  if (!transporter) {
    console.log(`\n[MAIL - SMTP yok] To: ${to}\nSubject: ${subject}\n${text}\n`);
    return true;
  }
  try {
    await transporter.sendMail({ from: env.MAIL_FROM, to, subject, text, html });
    return true;
  } catch (err) {
    console.error('E-posta gönderilemedi:', err.message);
    return false;
  }
}
