import crypto from 'node:crypto';
import jwt from 'jsonwebtoken';
import { env, isProd } from '../config/env.js';

export const SESSION_COOKIE = 'ep_session';

export function hashOtp(code) {
  return crypto.createHmac('sha256', env.OTP_SECRET).update(String(code)).digest('hex');
}
export function safeEqual(a, b) {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
export function generateOtp() {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
}

export function issueSession(res, user) {
  const token = jwt.sign({ sub: user.id, role: user.role }, env.JWT_SECRET, {
    expiresIn: `${env.JWT_EXPIRES_DAYS}d`,
    algorithm: 'HS256',
  });
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: isProd,
    sameSite: 'strict',
    maxAge: env.JWT_EXPIRES_DAYS * 24 * 60 * 60 * 1000,
    path: '/',
  });
}
export function clearSession(res) {
  res.clearCookie(SESSION_COOKIE, { httpOnly: true, secure: isProd, sameSite: 'strict', path: '/' });
}
export function verifyToken(token) {
  return jwt.verify(token, env.JWT_SECRET, { algorithms: ['HS256'] });
}

export function publicUser(u) {
  return {
    id: u.id,
    name: u.name,
    surname: u.surname,
    email: u.email,
    role: u.role,
    avatarUrl: u.avatarUrl,
    emailVerified: u.emailVerified,
    hasPassword: !!u.passwordHash,
    createdAt: u.createdAt,
  };
}
