# Eternal Production — Backend & Admin Paneli

Mevcut statik siteye (`public/`) şunları ekler: partner başvuru API'si, e-posta/şifre + OTP ve Google ile giriş, kullanıcı paneli (`/hesabim`), admin paneli (`/admin`).

**Stack:** Node.js 20+, Express, PostgreSQL + Prisma, JWT (HttpOnly cookie), Zod, Helmet, express-rate-limit, bcryptjs, Nodemailer.
Aynı kod hem normal bir Node sunucusu olarak (`npm start`) hem de **Vercel'de tek serverless fonksiyon** olarak (`api/index.js`) çalışır.

## Klasör yapısı

```
api/index.js            Vercel giriş noktası
prisma/                 schema.prisma + seed.js (ilk admin)
src/config/             env doğrulama, DB, mail
src/controllers/        auth, user, application, admin
src/middlewares/        auth guard, admin guard, rate limit, origin (CSRF) guard, hata yönetimi
src/routes/index.js     /api/v1/... rotaları
src/validators.js       Zod şemaları (tüm girdiler burada doğrulanır/temizlenir)
public/                 mevcut site + giris.html, hesabim.html, admin/ (admin arayüzü)
```

## 1) Gereksinimler
- Node.js **20+**
- PostgreSQL (önerilen: Supabase Free)
- (Opsiyonel) Google Cloud hesabı (Google girişi için), SMTP hesabı (OTP e-postası için)

## 2) Kurulum
```bash
npm install            # postinstall otomatik "prisma generate" çalıştırır
cp .env.example .env   # sonra .env dosyasını doldur
```

## 3) .env
| Değişken | Açıklama |
|---|---|
| `APP_URL` | Sitenin açık adresi (`http://localhost:3000` / `https://alanadin.com`) |
| `DATABASE_URL` | Supabase **Transaction pooler** (6543) + `?pgbouncer=true&connection_limit=1` |
| `DIRECT_URL` | Supabase **Direct connection** (5432) — sadece migrate/push için |
| `JWT_SECRET`, `OTP_SECRET` | Rastgele uzun değerler: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` |
| `GOOGLE_CLIENT_ID/SECRET` | Boşsa Google girişi kapalı (503) |
| `SMTP_*`, `MAIL_FROM` | Boşsa e-postalar **konsola** yazılır (sadece geliştirme!) |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD` | `npm run db:seed` bu admin'i oluşturur (şifre ≥ 10 karakter) |
| `ADMIN_NOTIFY_EMAIL` | Yeni başvuru bildirimi adresi (boşsa `ADMIN_EMAIL`) |

### Google OAuth
Google Cloud Console → APIs & Services → Credentials → *OAuth client ID* (Web application).
**Authorized redirect URI:** `APP_URL + /api/v1/auth/google/callback` (örn. `https://alanadin.com/api/v1/auth/google/callback`; yerelde `http://localhost:3000/api/v1/auth/google/callback`).

## 4) Veritabanı ve admin
```bash
npm run db:push        # tabloları oluşturur (ilk kurulum için en kolayı)
npm run db:seed        # .env'deki ADMIN_EMAIL/ADMIN_PASSWORD ile admin oluşturur
```
Migration geçmişi tutmak istersen: `npm run db:migrate:dev -- --name init` (yerelde), üretimde `npm run db:migrate`.

## 5) Çalıştırma
```bash
npm run dev    # geliştirme (otomatik yeniden başlar)
npm start      # üretim
```
Site: `http://localhost:3000` · Admin: `http://localhost:3000/admin` (admin hesabıyla `/giris` üzerinden giriş yap).

## 6) Vercel'e yayınlama (GitHub → Vercel → kendi domainin)
1. Projeyi GitHub'a push et (`.env` push edilmez, `.gitignore`'da).
2. vercel.com → *Add New Project* → repoyu seç. Framework: **Other**. Build/Output ayarlarına dokunma.
3. *Settings → Environment Variables*: `.env.example`'daki tüm değişkenleri gir. `NODE_ENV=production`, `APP_URL=https://alanadin.com`.
4. Deploy et. Tabloları oluşturmak için **kendi bilgisayarında** `.env`'ye Supabase bilgilerini koyup `npm run db:push && npm run db:seed` çalıştır.
5. *Settings → Domains* → domainini ekle, Vercel'in verdiği DNS kayıtlarını (A / CNAME) alan adı sağlayıcında gir.
6. Google Console'daki redirect URI'yi yeni domaine göre güncelle.

## 7) API (`/api/v1`)
Tüm POST/PATCH/DELETE istekleri `Content-Type: application/json` ve aynı origin'den gelmeli (Origin kontrolü).

| Metot | Yol | Açıklama |
|---|---|---|
| POST | `/auth/register` | `{name,surname,email,password}` → OTP e-postası gönderir |
| POST | `/auth/verify-otp` | `{email,code}` → hesabı aktifler, oturum açar |
| POST | `/auth/resend-otp` | `{email}` (60 sn bekleme) |
| POST | `/auth/login` | `{email,password}` |
| POST | `/auth/logout` | |
| GET | `/auth/me` | Oturumdaki kullanıcı veya `null` |
| GET | `/auth/google` | Google'a yönlendirir |
| POST | `/applications` | Başvuru (**oturum opsiyonel**; oturum açıksa hesaba bağlanır) |
| PATCH | `/user/profile` | `{name,surname}` — yalnızca isim/soyisim |
| GET | `/user/applications` | Başvurularım + admin yanıtları |
| GET | `/user/sites` | Bana atanan siteler |
| GET | `/admin/stats` · `/admin/applications?status=&q=&page=` · `/admin/applications/:id` | Admin |
| PATCH | `/admin/applications/:id/status` | `{status: PENDING\|REVIEWING\|APPROVED\|REJECTED, notify?}` |
| POST | `/admin/applications/:id/messages` | `{body, sendEmail}` |
| GET | `/admin/users?q=&page=` · `/admin/users/:id` | Kullanıcılar |
| POST | `/admin/users/:id/sites` | `{domain,label?}` site ata |
| DELETE | `/admin/sites/:id` | Site sil |
| PATCH | `/admin/profile/avatar` | `{avatarUrl}` (`https://`; boş = kaldır) |

Örnek:
```bash
curl -X POST http://localhost:3000/api/v1/auth/login -H "Content-Type: application/json" \
  -H "Origin: http://localhost:3000" -c jar.txt -d '{"email":"admin@ornek.com","password":"..."}'
```

## 8) Güvenlik özeti
- **Rate limit:** genel API, giriş/kayıt, OTP ve başvuru için ayrı limitler. OTP ayrıca 5 yanlış denemede kilitlenir, kod 10 dk geçerlidir ve veritabanında HMAC hash olarak saklanır.
- **Şifre:** bcrypt (cost 12), 8–72 karakter, harf+rakam; giriş zamanlaması kullanıcı var/yok bilgisini sızdırmaz.
- **Oturum:** JWT yalnızca `HttpOnly; SameSite=Strict; Secure(prod)` çerezde. Her istekte kullanıcı DB'den doğrulanır (silinen/rolü değişen kullanıcı hemen etkilenir).
- **CSRF:** SameSite=Strict + durum değiştiren isteklerde Origin/Referer allowlist kontrolü.
- **Girdi:** Zod ile doğrulama, Prisma ile parametreli sorgu (SQL injection yok), arayüzde `textContent` (XSS yok), CSP `script-src 'self'`.
- **Google OAuth:** `state` çerezi ile CSRF koruması; yalnızca `email_verified` hesaplar; doğrulanmamış şifreli ön-kayıt varsa Google bağlanınca şifre silinir.
- **Admin avatarı:** URL sunucuda indirilmez (SSRF riski); sadece `https://` URL saklanır, tarayıcı gösterir.

## 9) Bilinen sınırlar
- Rate limit sayaçları **bellekte** tutulur. Vercel'de her fonksiyon örneği ayrı sayar; ciddi saldırı için Upstash Redis gibi ortak bir store eklenmeli.
- Başvuru formundaki e-posta doğrulanmaz (oturumsuz başvuru); bu yüzden başvuru sahibine otomatik e-posta gönderilmez, yalnızca admin yanıt verince gönderilir.
- Yerel testte `http://localhost` üzerinde `Secure` çerez kapalıdır; üretimde HTTPS zorunludur.
