/* Eternal Production — Admin Paneli (bağımlılıksız; tüm içerik textContent ile basılır, XSS'e kapalı) */
(() => {
  const $ = (id) => document.getElementById(id);
  const STATUS_TR = { PENDING: "Beklemede", REVIEWING: "İncelemede", APPROVED: "Onaylandı", REJECTED: "Reddedildi" };
  const fmt = (d) => new Date(d).toLocaleString("tr-TR", { dateStyle: "short", timeStyle: "short" });
  let me = null;

  async function api(path, { method = "GET", body } = {}) {
    const res = await fetch(`/api/v1${path}`, {
      method, credentials: "same-origin",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Bir hata oluştu.");
    return data;
  }
  function h(tag, props = {}, ...kids) {
    const n = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") n.className = v;
      else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
      else if (v !== undefined && v !== null && v !== false) n.setAttribute(k, v === true ? "" : v);
    }
    n.append(...kids.flat().filter((x) => x !== null && x !== undefined && x !== false));
    return n;
  }
  let toastTimer;
  function toast(msg, isErr = false) {
    const t = $("toast");
    t.textContent = msg;
    t.className = `toast${isErr ? " err" : ""}`;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.add("hidden"), 3500);
  }
  const badge = (s) => h("span", { class: `badge st-${s}` }, STATUS_TR[s] || s);
  const debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  /* ---------- Giriş kontrolü ---------- */
  async function boot() {
    try { ({ user: me } = await api("/auth/me")); } catch { /* yoksay */ }
    const gate = $("gate");
    if (!me) {
      gate.replaceChildren(h("div", {}, h("h2", {}, "Admin Paneli"), h("p", { class: "muted" }, "Devam etmek için giriş yapın."),
        h("p", { style: "margin-top:14px" }, h("a", { href: "/giris.html?next=admin" }, "Giriş yap →"))));
      return;
    }
    if (me.role !== "ADMIN") {
      gate.replaceChildren(h("div", {}, h("h2", {}, "Yetkiniz yok"), h("p", { class: "muted" }, "Bu sayfa yalnızca yöneticiler içindir."),
        h("p", { style: "margin-top:14px" }, h("a", { href: "/hesabim.html" }, "Hesabıma dön"))));
      return;
    }
    gate.classList.add("hidden");
    $("app").classList.remove("hidden");
    renderMe();
    wire();
    loadStats();
    loadApplications();
  }

  function renderMe() {
    $("meName").textContent = `${me.name} ${me.surname}`.trim();
    for (const id of ["meAvatar", "avatarPreview"]) {
      const img = $(id);
      if (me.avatarUrl) { img.src = me.avatarUrl; img.classList.remove("hidden"); } else { img.removeAttribute("src"); img.classList.add("hidden"); }
    }
    $("avatarUrl").value = me.avatarUrl || "";
  }

  function wire() {
    document.querySelectorAll(".side nav button").forEach((b) => b.addEventListener("click", () => {
      document.querySelectorAll(".side nav button").forEach((x) => x.classList.toggle("is-active", x === b));
      document.querySelectorAll(".tab").forEach((t) => t.classList.toggle("hidden", t.id !== `tab-${b.dataset.tab}`));
      if (b.dataset.tab === "users") loadUsers();
      if (b.dataset.tab === "applications") loadApplications();
    }));
    $("logout").addEventListener("click", async () => { await api("/auth/logout", { method: "POST" }).catch(() => {}); location.href = "/"; });
    $("appSearch").addEventListener("input", debounce(() => { appPage = 1; loadApplications(); }));
    $("appStatus").addEventListener("change", () => { appPage = 1; loadApplications(); });
    $("userSearch").addEventListener("input", debounce(() => { userPage = 1; loadUsers(); }));
    $("drawerBg").addEventListener("click", closeDrawer);
    $("drawerClose").addEventListener("click", closeDrawer);
    $("avatarForm").addEventListener("submit", (e) => { e.preventDefault(); saveAvatar($("avatarUrl").value); });
    $("avatarClear").addEventListener("click", () => saveAvatar(""));
  }

  async function saveAvatar(url) {
    try {
      const d = await api("/admin/profile/avatar", { method: "PATCH", body: { avatarUrl: url } });
      me = d.user; renderMe(); toast("Profil resmi güncellendi.");
    } catch (e) { toast(e.message, true); }
  }

  async function loadStats() {
    try {
      const s = await api("/admin/stats");
      $("stats").replaceChildren(
        ...[["Kullanıcı", s.users], ...Object.entries(s.applications).map(([k, v]) => [STATUS_TR[k], v])]
          .map(([l, v]) => h("div", { class: "stat" }, h("b", {}, String(v)), h("span", {}, l))));
    } catch (e) { toast(e.message, true); }
  }

  function pager(box, page, total, size, go) {
    const pages = Math.max(1, Math.ceil(total / size));
    box.replaceChildren(
      h("span", {}, `${total} kayıt · Sayfa ${page}/${pages}`),
      h("button", { class: "ghost", disabled: page <= 1, onclick: () => go(page - 1) }, "‹ Önceki"),
      h("button", { class: "ghost", disabled: page >= pages, onclick: () => go(page + 1) }, "Sonraki ›"));
  }

  /* ---------- Başvurular ---------- */
  let appPage = 1;
  async function loadApplications() {
    const qs = new URLSearchParams({ page: appPage });
    if ($("appSearch").value.trim()) qs.set("q", $("appSearch").value.trim());
    if ($("appStatus").value) qs.set("status", $("appStatus").value);
    try {
      const d = await api(`/admin/applications?${qs}`);
      $("appRows").replaceChildren(...(d.items.length ? d.items.map((a) =>
        h("tr", { onclick: () => openApplication(a.id) },
          h("td", {}, fmt(a.createdAt)), h("td", {}, a.fullname), h("td", {}, a.nickname),
          h("td", {}, a.instagram), h("td", {}, a.followers), h("td", {}, badge(a.status))))
        : [h("tr", {}, h("td", { colspan: "6" }, "Başvuru bulunamadı."))]));
      pager($("appPager"), d.page, d.total, d.pageSize, (p) => { appPage = p; loadApplications(); });
    } catch (e) { toast(e.message, true); }
  }

  function openDrawer(content) { $("drawerContent").replaceChildren(content); $("drawer").classList.remove("hidden"); }
  function closeDrawer() { $("drawer").classList.add("hidden"); }

  async function openApplication(id) {
    try {
      const { application: a } = await api(`/admin/applications/${id}`);
      const kv = [["Ad Soyad", a.fullname], ["Takma Ad", a.nickname], ["Instagram (kullanıcı adı)", a.instagramHandle], ["E-posta", a.email],
        ["Instagram", a.instagram], ["Takipçi", a.followers], ["İçerik Türü", a.contentType], ["Ort. İzlenme", a.avgViews],
        ["Reklam Onayı", a.adConsent], ["Hakkında", a.about], ["Neden biz?", a.why], ["Tarih", fmt(a.createdAt)],
        ["Hesap", a.user ? `${a.user.name} ${a.user.surname} <${a.user.email}>` : "Oturumsuz (anonim) başvuru"]];

      const select = h("select", {}, ...Object.entries(STATUS_TR).map(([v, l]) => h("option", { value: v, selected: v === a.status }, l)));
      const notify = h("input", { type: "checkbox", id: "notifyChk" });
      const msgList = h("div", {}, ...a.messages.map(msgNode));
      const textarea = h("textarea", { placeholder: "Başvuru sahibine yanıt yazın...", maxlength: "4000" });
      const mailChk = h("input", { type: "checkbox", checked: true });

      const content = h("div", {},
        h("h2", {}, a.nickname), h("div", { style: "margin-top:6px" }, badge(a.status)),
        h("dl", { class: "kv" }, ...kv.flatMap(([k, v]) => [h("dt", {}, k), h("dd", {}, v)])),
        h("div", { class: "sec" }, h("h3", {}, "Durumu değiştir"),
          select,
          h("label", { class: "chk" }, notify, "Başvuru sahibine e-posta ile bildir"),
          h("div", { class: "row" }, h("button", { class: "primary", onclick: async () => {
            try { await api(`/admin/applications/${a.id}/status`, { method: "PATCH", body: { status: select.value, notify: notify.checked } });
              toast("Durum güncellendi."); loadApplications(); loadStats(); openApplication(a.id); } catch (e) { toast(e.message, true); } } }, "Kaydet"))),
        h("div", { class: "sec" }, h("h3", {}, "Mesajlar"), msgList,
          textarea,
          h("label", { class: "chk" }, mailChk, "E-posta olarak da gönder"),
          h("div", { class: "row" }, h("button", { class: "primary", onclick: async (ev) => {
            const btn = ev.currentTarget; btn.disabled = true;
            try { const d = await api(`/admin/applications/${a.id}/messages`, { method: "POST", body: { body: textarea.value, sendEmail: mailChk.checked } });
              msgList.append(msgNode(d.message)); textarea.value = ""; toast(d.message.emailed ? "Mesaj gönderildi ve e-postalandı." : "Mesaj kaydedildi."); }
            catch (e) { toast(e.message, true); } finally { btn.disabled = false; } } }, "Gönder"))));
      openDrawer(content);
    } catch (e) { toast(e.message, true); }
  }
  const msgNode = (m) => h("div", { class: "msg" }, m.body, h("small", {}, `${fmt(m.createdAt)}${m.emailed ? " · e-posta gönderildi" : ""}`));

  /* ---------- Kullanıcılar ---------- */
  let userPage = 1;
  async function loadUsers() {
    const qs = new URLSearchParams({ page: userPage });
    if ($("userSearch").value.trim()) qs.set("q", $("userSearch").value.trim());
    try {
      const d = await api(`/admin/users?${qs}`);
      $("userRows").replaceChildren(...(d.items.length ? d.items.map((u) =>
        h("tr", { onclick: () => openUser(u.id) },
          h("td", {}, fmt(u.createdAt)), h("td", {}, `${u.name} ${u.surname}`.trim()), h("td", {}, u.email),
          h("td", {}, u.role), h("td", {}, String(u.applications)), h("td", {}, String(u.sites))))
        : [h("tr", {}, h("td", { colspan: "6" }, "Kullanıcı bulunamadı."))]));
      pager($("userPager"), d.page, d.total, d.pageSize, (p) => { userPage = p; loadUsers(); });
    } catch (e) { toast(e.message, true); }
  }

  async function openUser(id) {
    try {
      const { user: u } = await api(`/admin/users/${id}`);
      const domain = h("input", { placeholder: "ornek.com", maxlength: "253" });
      const label = h("input", { placeholder: "Etiket (opsiyonel)", maxlength: "80" });
      const siteList = h("div", {});
      const addSiteRow = (s) => {
        const row = h("div", { class: "site-row" }, h("span", {}, s.label ? `${s.domain} — ${s.label}` : s.domain),
          h("button", { class: "danger", onclick: async () => {
            if (!confirm(`${s.domain} sitesi bu kullanıcıdan kaldırılsın mı?`)) return;
            try { await api(`/admin/sites/${s.id}`, { method: "DELETE" }); row.remove(); toast("Site kaldırıldı."); loadUsers(); } catch (e) { toast(e.message, true); } } }, "Sil"));
        siteList.append(row);
      };
      u.sites.forEach(addSiteRow);

      openDrawer(h("div", {},
        h("h2", {}, `${u.name} ${u.surname}`.trim()),
        h("dl", { class: "kv" }, h("dt", {}, "E-posta"), h("dd", {}, u.email), h("dt", {}, "Rol"), h("dd", {}, u.role),
          h("dt", {}, "Giriş yöntemi"), h("dd", {}, u.hasPassword ? "E-posta/şifre" : "Google"), h("dt", {}, "Kayıt"), h("dd", {}, fmt(u.createdAt))),
        h("div", { class: "sec" }, h("h3", {}, "Kayıtlı siteler"), siteList,
          h("label", {}, "Yeni site ata"), domain, h("div", { style: "height:8px" }), label,
          h("div", { class: "row" }, h("button", { class: "primary", onclick: async () => {
            try { const d = await api(`/admin/users/${u.id}/sites`, { method: "POST", body: { domain: domain.value, label: label.value } });
              addSiteRow(d.site); domain.value = ""; label.value = ""; toast("Site atandı."); loadUsers(); } catch (e) { toast(e.message, true); } } }, "Ata"))),
        h("div", { class: "sec" }, h("h3", {}, "Başvurular"),
          ...(u.applications.length ? u.applications.map((a) => h("div", { class: "site-row" }, h("span", {}, `${a.nickname} · ${fmt(a.createdAt)}`), badge(a.status)))
            : [h("p", { class: "muted" }, "Başvurusu yok.")]))));
    } catch (e) { toast(e.message, true); }
  }

  boot();
})();
