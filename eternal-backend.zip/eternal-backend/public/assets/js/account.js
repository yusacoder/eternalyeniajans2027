/** Eternal Production — giriş / kayıt / OTP / hesabım sayfası mantığı */
(() => {
  const STATUS_TR = { PENDING: "Beklemede", REVIEWING: "İncelemede", APPROVED: "Onaylandı", REJECTED: "Reddedildi" };
  const $ = (id) => document.getElementById(id);

  async function api(path, { method = "GET", body } = {}) {
    const res = await fetch(`/api/v1${path}`, {
      method,
      credentials: "same-origin",
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || "Bir hata oluştu.");
      err.code = data.code;
      throw err;
    }
    return data;
  }

  function el(tag, props = {}, ...children) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === "class") node.className = v;
      else node.setAttribute(k, v);
    }
    node.append(...children);
    return node;
  }
  const fmt = (d) => new Date(d).toLocaleDateString("tr-TR", { day: "2-digit", month: "long", year: "numeric" });
  function show(box, msg, ok = false) {
    box.textContent = msg;
    box.className = ok ? "form-ok" : "form-error";
    box.classList.remove("hidden");
  }
  const hide = (box) => box.classList.add("hidden");

  // Yalnızca site içi basit dosya adlarına yönlendirme (open redirect koruması)
  function nextUrl() {
    const n = new URLSearchParams(location.search).get("next");
    return n && /^[a-z0-9-]+(\.html)?$/i.test(n) ? n : "hesabim.html";
  }

  /* ---------------- giris.html ---------------- */
  function initAuthPage() {
    const msg = $("authMsg");
    let pendingEmail = "";

    if (new URLSearchParams(location.search).get("error") === "google") {
      show(msg, "Google ile giriş tamamlanamadı. Lütfen tekrar deneyin.");
    }
    api("/auth/me").then((d) => { if (d.user) location.href = nextUrl(); }).catch(() => {});

    const switchTab = (login) => {
      $("tabLogin").classList.toggle("is-active", login);
      $("tabRegister").classList.toggle("is-active", !login);
      $("loginForm").classList.toggle("hidden", !login);
      $("registerForm").classList.toggle("hidden", login);
      hide(msg);
    };
    $("tabLogin").addEventListener("click", () => switchTab(true));
    $("tabRegister").addEventListener("click", () => switchTab(false));

    const showOtp = (email) => {
      pendingEmail = email;
      $("otpEmail").textContent = email;
      $("authBox").classList.add("hidden");
      $("otpForm").classList.remove("hidden");
      $("otp_code").focus();
    };

    $("loginForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      hide(msg);
      try {
        await api("/auth/login", { method: "POST", body: { email: $("l_email").value, password: $("l_pass").value } });
        location.href = nextUrl();
      } catch (err) {
        if (err.code === "EMAIL_NOT_VERIFIED") { showOtp($("l_email").value.trim().toLowerCase()); show(msg, err.message, true); }
        else show(msg, err.message);
      }
    });

    $("registerForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      hide(msg);
      try {
        const email = $("r_email").value;
        await api("/auth/register", { method: "POST", body: { name: $("r_name").value, surname: $("r_surname").value, email, password: $("r_pass").value } });
        showOtp(email.trim().toLowerCase());
      } catch (err) { show(msg, err.message); }
    });

    $("otpForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      hide(msg);
      try {
        await api("/auth/verify-otp", { method: "POST", body: { email: pendingEmail, code: $("otp_code").value.trim() } });
        location.href = nextUrl();
      } catch (err) { show(msg, err.message); }
    });

    $("resendBtn").addEventListener("click", async () => {
      try {
        await api("/auth/resend-otp", { method: "POST", body: { email: pendingEmail } });
        show(msg, "Yeni kod gönderildi (varsa).", true);
      } catch (err) { show(msg, err.message); }
    });
  }

  /* ---------------- hesabim.html ---------------- */
  async function initAccountPage() {
    const msg = $("accountMsg");
    let user;
    try {
      ({ user } = await api("/auth/me"));
    } catch { /* aşağıda yönlendirilir */ }
    if (!user) { location.href = "giris.html?next=hesabim.html"; return; }

    $("welcome").textContent = `Hoş geldin, ${user.name}`;
    $("welcomeMail").textContent = user.email;
    $("p_name").value = user.name;
    $("p_surname").value = user.surname;
    if (user.role === "ADMIN") $("adminLink").classList.remove("hidden");

    $("profileForm").addEventListener("submit", async (e) => {
      e.preventDefault();
      hide(msg);
      try {
        const d = await api("/user/profile", { method: "PATCH", body: { name: $("p_name").value, surname: $("p_surname").value } });
        $("welcome").textContent = `Hoş geldin, ${d.user.name}`;
        show(msg, "Profil güncellendi.", true);
      } catch (err) { show(msg, err.message); }
    });

    $("logoutBtn").addEventListener("click", async () => {
      await api("/auth/logout", { method: "POST" }).catch(() => {});
      location.href = "index.html";
    });

    try {
      const { applications } = await api("/user/applications");
      const list = $("appList");
      list.textContent = "";
      if (!applications.length) list.append(el("p", { class: "muted" }, "Henüz hesabına bağlı bir başvurun yok."));
      for (const a of applications) {
        const item = el("div", { class: "app-item" },
          el("div", { class: "app-head" },
            el("strong", {}, a.nickname),
            el("span", { class: `status-badge st-${a.status}` }, STATUS_TR[a.status] || a.status)),
          el("div", { class: "muted" }, `${a.instagram} · ${fmt(a.createdAt)}`));
        for (const m of a.messages) {
          item.append(el("div", { class: "msg-bubble" }, m.body), el("div", { class: "muted" }, fmt(m.createdAt)));
        }
        list.append(item);
      }
    } catch (err) { $("appList").textContent = err.message; }

    try {
      const { sites } = await api("/user/sites");
      const list = $("siteList");
      list.textContent = "";
      if (!sites.length) list.append(el("p", { class: "muted" }, "Sana henüz bir site atanmadı."));
      for (const s of sites) {
        list.append(el("div", { class: "site-item" },
          el("strong", {}, s.domain),
          s.label ? el("span", { class: "muted" }, ` — ${s.label}`) : ""));
      }
    } catch (err) { $("siteList").textContent = err.message; }
  }

  document.addEventListener("DOMContentLoaded", () => {
    if ($("loginForm")) initAuthPage();
    if ($("profileForm")) initAccountPage();
  });
})();
