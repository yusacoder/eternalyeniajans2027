/**
 * Eternal Production — Multi-step Partner Application Form Manager
 */
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("applicationForm");
  if (!form) return;

  const steps = Array.from(form.querySelectorAll(".form-step"));
  const dots = Array.from(document.querySelectorAll(".step-dot"));
  const reviewList = document.getElementById("reviewList");

  let currentStep = 0;

  function showStep(stepIndex) {
    steps.forEach((step, idx) => {
      if (idx === stepIndex) {
        step.classList.add("is-active");
      } else {
        step.classList.remove("is-active");
      }
    });

    dots.forEach((dot, idx) => {
      if (idx <= stepIndex) {
        dot.classList.add("is-active");
      } else {
        dot.classList.remove("is-active");
      }
    });

    currentStep = stepIndex;

    // Scroll form into view gently
    form.scrollIntoView({ behavior: "smooth", block: "nearest" });

    // If we are on the final step, build the summary
    if (stepIndex === steps.length - 1) {
      buildReviewSummary();
    }
  }

  function validateStep(stepIndex) {
    const stepEl = steps[stepIndex];
    const inputs = stepEl.querySelectorAll("input[required], select[required], textarea[required]");
    let isValid = true;

    // Simple validation loop
    inputs.forEach(input => {
      // Remove any existing errors
      input.classList.remove("input-error");
      const errLabel = input.parentNode.querySelector(".error-message");
      if (errLabel) errLabel.remove();

      if (input.type === "radio") {
        // Check if any radio with the same name is checked
        const radios = stepEl.querySelectorAll(`input[name="${input.name}"]`);
        const checked = Array.from(radios).some(r => r.checked);
        if (!checked) {
          isValid = false;
          // Highlight container
          const choiceRow = input.closest(".choice-row");
          if (choiceRow && !choiceRow.parentNode.querySelector(".error-message")) {
            const err = document.createElement("span");
            err.className = "error-message";
            err.innerText = "Lütfen bir seçim yapınız.";
            choiceRow.parentNode.appendChild(err);
          }
        }
      } else if (!input.value.trim()) {
        isValid = false;
        input.classList.add("input-error");

        // Add error label
        const err = document.createElement("span");
        err.className = "error-message";
        err.innerText = "Bu alanın doldurulması zorunludur.";
        input.parentNode.appendChild(err);
      } else if (input.type === "email") {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(input.value.trim())) {
          isValid = false;
          input.classList.add("input-error");

          const err = document.createElement("span");
          err.className = "error-message";
          err.innerText = "Geçersiz e-posta formatı.";
          input.parentNode.appendChild(err);
        }
      }
    });

    return isValid;
  }

  const esc = (v) => String(v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  function buildReviewSummary() {
    if (!reviewList) return;

    const data = {
      "Ad Soyad": form.elements["fullname"].value,
      "Takma Ad": form.elements["nickname"].value,
      "Discord": form.elements["discord"].value,
      "E-posta": form.elements["email"].value,
      "Instagram": form.elements["instagram"].value,
      "Takipçi Sayısı": form.elements["followers"].value,
      "İçerik Türü": form.elements["content_type"].value,
      "Ortalama İzlenme": form.elements["avg_views"].value,
      "Hakkında": form.elements["about"].value,
      "Neden Biz?": form.elements["why"].value,
      "Reklam Onayı": form.elements["ad_consent"].value
    };

    let summaryHTML = `<h4>Başvuru Özetiniz</h4><dl class="review-dl">`;
    for (const [key, val] of Object.entries(data)) {
      summaryHTML += `
        <div class="review-row">
          <dt>${key}</dt>
          <dd>${esc(val || "-")}</dd>
        </div>
      `;
    }
    summaryHTML += `</dl>`;

    reviewList.innerHTML = summaryHTML;
  }

  // Next / Previous buttons listeners
  form.addEventListener("click", (e) => {
    if (e.target.hasAttribute("data-next")) {
      if (validateStep(currentStep)) {
        showStep(currentStep + 1);
      }
    } else if (e.target.hasAttribute("data-prev")) {
      showStep(currentStep - 1);
    }
  });

  // Handle Form Submission -> POST /api/v1/applications
  const errorBox = document.getElementById("formError");
  const submitBtn = document.getElementById("submitBtn");

  function showError(msg) {
    if (!errorBox) return alert(msg);
    errorBox.textContent = msg;
    errorBox.hidden = false;
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    if (errorBox) errorBox.hidden = true;
    if (!validateStep(currentStep)) return;

    const agreeRules = document.getElementById("agree_rules");
    const agreeContent = document.getElementById("agree_content");
    const agreePrivacy = document.getElementById("agree_privacy");
    if (!agreeRules.checked || !agreeContent.checked || !agreePrivacy.checked) {
      showError("Lütfen tüm sözleşmeleri okuyup onaylayınız.");
      return;
    }

    const payload = {};
    new FormData(form).forEach((value, key) => { payload[key] = String(value); });

    // Honeypot dolu ise (bot) sessizce teşekkür sayfasına yönlendir
    if (payload._honey) { window.location.href = "tesekkurler.html"; return; }

    submitBtn.disabled = true;
    submitBtn.textContent = "Gönderiliyor...";
    try {
      const res = await fetch("/api/v1/applications", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Başvuru gönderilemedi. Lütfen tekrar deneyin.");
      window.location.href = "tesekkurler.html";
    } catch (err) {
      showError(err.message || "Bağlantı hatası. Lütfen tekrar deneyin.");
      submitBtn.disabled = false;
      submitBtn.textContent = "Gönder";
    }
  });

  // Oturum açıksa bannerı güncelle ve bilinen alanları doldur
  fetch("/api/v1/auth/me", { credentials: "same-origin" })
    .then((r) => (r.ok ? r.json() : null))
    .then((data) => {
      if (!data || !data.user) return;
      const banner = document.getElementById("sessionBannerText");
      if (banner) {
        banner.textContent = "";
        const strong = document.createElement("strong");
        strong.textContent = data.user.email;
        banner.append("Şu an ", strong, " olarak giriş yaptınız; başvurunuz hesabınıza bağlanacak. ");
        const a = document.createElement("a");
        a.href = "hesabim.html";
        a.textContent = "Hesabım";
        banner.append(a);
      }
      const email = form.elements["email"];
      const fullname = form.elements["fullname"];
      if (email && !email.value) email.value = data.user.email;
      if (fullname && !fullname.value) fullname.value = `${data.user.name} ${data.user.surname}`.trim();
    })
    .catch(() => {});
});
