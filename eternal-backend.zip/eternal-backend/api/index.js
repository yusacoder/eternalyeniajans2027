// Vercel giriş noktası: tüm /api/* istekleri bu fonksiyona yönlenir.
import app from '../src/app.js';
export default app;
