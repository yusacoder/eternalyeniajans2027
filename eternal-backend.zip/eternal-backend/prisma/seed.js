import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
const email = (process.env.ADMIN_EMAIL || '').trim().toLowerCase();
const password = process.env.ADMIN_PASSWORD || '';

if (!email || password.length < 10) {
  console.error('ADMIN_EMAIL ve en az 10 karakterlik ADMIN_PASSWORD .env içinde tanımlı olmalı.');
  process.exit(1);
}

const passwordHash = await bcrypt.hash(password, 12);
const admin = await prisma.user.upsert({
  where: { email },
  update: { role: 'ADMIN', passwordHash, emailVerified: true },
  create: {
    email,
    name: process.env.ADMIN_NAME || 'Admin',
    passwordHash,
    role: 'ADMIN',
    emailVerified: true,
  },
});
console.log(`Admin hazır: ${admin.email}`);
await prisma.$disconnect();
